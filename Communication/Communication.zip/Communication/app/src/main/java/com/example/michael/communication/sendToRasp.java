package com.example.michael.communication;


import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class sendToRasp {

    int abmase, objekte, position;
    String url ="10.0.0.20:12500/sendToRasp";

    public void JSON() {
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        Map<String,String> params = new HashMap<String, String>();

        params.put("höhe", String.valueOf(abmase));
        params.put("objekte", String.valueOf(objekte));
        params.put("position", String.valueOf(position));

        JSONObject jsonObject = new JSONObject(params);
        OkHttpClient client = new OkHttpClient();

        RequestBody requestBody = RequestBody.create(JSON, jsonObject.toString());
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("conten-type", "application/json; charset=utf-8")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

            }


        });

    }
}