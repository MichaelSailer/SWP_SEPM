package com.example.michael.communication;


import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class sendToTablet {


    String url = "10.0.0.20:5000/sendToTablet";

    public void ReadfromDatabase(){
        OkHttpClient client = new OkHttpClient();
        String url = "http://10.0.0.20:5000/sendToTablet";

        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if(response.isSuccessful()){
                    final String myResponse = response.body().string();
{
                            myResponse.split(",");
                            System.out.println(myResponse);
                        }

                }
            }
        });
    }
}