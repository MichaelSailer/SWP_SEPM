package com.example.michael.communication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.DigitalClock;
import android.widget.TextView;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class test extends AppCompatActivity {


    TextView textView;
    Button button;
    DigitalClock digitalClock;
    AnalogClock analogClock;

    int counter = 0;
    int xpos,ypos,größe,breite,objekte;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        textView = findViewById(R.id.textView);
        textView.setY(100);
        textView.setX(100);
        textView.setTextSize(20);
        textView.setVisibility(View.VISIBLE);
        button = findViewById(R.id.button);
        button.setY(150);
        button.setX(25);
        button.setTextSize(20);
        button.setVisibility(View.VISIBLE);
        digitalClock = findViewById(R.id.clock);
        analogClock = findViewById(R.id.aclock);

        digitalClock.setVisibility(View.INVISIBLE);
        analogClock.setVisibility(View.INVISIBLE);


        button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Reload();
           }
       });


    }

    void Reload(){
        OkHttpClient client = new OkHttpClient();
        String url = "http://91.114.238.38:12500/sendToTablet";

        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if(response.isSuccessful()){
                    final String myResponse = response.body().string();

                    test.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String string1 = myResponse.replace("[","");
                            String string2 = string1.replace("]","");
                            String string3 = string2.replace("\"","");
                            String[] werte = string3.split(",");

                            int länge = werte.length / 5;

                            for(int i = 1; i<=länge; i++){
                                if(counter == 5){
                                    counter = 0;
                                }else{
                                    counter++;
                                    xpos = Integer.parseInt(werte[i]);
                                    ypos = Integer.parseInt(werte[i+1]);
                                    größe = Integer.parseInt(werte[i+2]);
                                    breite = Integer.parseInt(werte[i+3]);
                                    objekte = Integer.parseInt(werte[i+4]);

                                }
                            }


                        }
                    });
                }
            }
        });

    }
    public  void aktivierung(int xpos,int ypos,int größe,int breite, int objekte){
        switch (objekte){
            case 1:

                digitalClock.setX(xpos);
                digitalClock.setY(ypos);
                digitalClock.setTextSize(größe);
                digitalClock.setVisibility(View.VISIBLE);
                break;
            case 2:
                analogClock.setX(xpos);
                analogClock.setY(ypos);
                analogClock.setScaleY(größe / 10);
                analogClock.setScaleX(breite / 10);
                analogClock.setVisibility(View.VISIBLE);
                break;
        }



    }
}