package com.example.michael.communication;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.DigitalClock;
import android.widget.TextView;

import java.util.Random;

public class Spiegel_test extends AppCompatActivity {

    DigitalClock digitalClock;
    AnalogClock analogClock;
    TextView textView;

    int xpos=0,ypos=0,größe=20,breite,objekte=3;
    String text="Hello World";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spiegel_test);
        digitalClock = findViewById(R.id.clock);
        analogClock = findViewById(R.id.aclock);
        textView = findViewById(R.id.stickyNotes);

        digitalClock.setVisibility(View.INVISIBLE);
        analogClock.setVisibility(View.INVISIBLE);
        textView.setVisibility(View.INVISIBLE);

        aktivierung(xpos,ypos,größe,breite,objekte,text);
    }
    public  void aktivierung(int xpos,int ypos,int größe,int breite, int objekte, String text){
        switch (objekte){
            case 1:

                digitalClock.setX(xpos);
                digitalClock.setY(ypos);
                digitalClock.setTextSize(größe);
                digitalClock.setVisibility(View.VISIBLE);
                break;
            case 2:
                analogClock.setX(xpos);
                analogClock.setY(ypos);
                analogClock.setScaleY(größe / 10);
                analogClock.setScaleX(breite / 10);
                analogClock.setVisibility(View.VISIBLE);
                break;

            case 3:
                Random rnd = new Random();
                int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                textView.setX(xpos);
                textView.setY(ypos);
                textView.setTextSize(größe);
                textView.setBackgroundColor(color);
                textView.setText(text);
                textView.setVisibility(View.VISIBLE);
                break;
        }



    }
}
